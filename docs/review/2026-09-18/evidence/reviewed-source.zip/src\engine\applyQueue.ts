import type { ApplyOutcome, Blackboard, BlackboardDelta } from "./blackboard";
import type { TensionLevel } from "./schema";

export interface TurnRange {
  from: number;
  to: number;
}

export interface ApplyQueueEntry {
  source: "mechanical" | "extractor" | "reconciliation";
  blackboardVersionSum: number;
  turnRange?: TurnRange;
  deltas: BlackboardDelta[];
  tensionLevels?: TensionLevel[];
}

export interface AppliedQueueEntry extends ApplyQueueEntry {
  outcomes: ApplyOutcome[];
}

export interface QueueDrainResult {
  applied: AppliedQueueEntry[];
  discarded: ApplyQueueEntry[];
}

const covers = (newer: TurnRange | undefined, older: TurnRange | undefined): boolean => {
  return Boolean(newer && older && newer.from <= older.from && newer.to >= older.to);
};

export class ApplyQueue {
  private entries: ApplyQueueEntry[] = [];

  enqueue(entry: ApplyQueueEntry): void {
    this.entries.push({ ...entry, deltas: entry.deltas.map((delta) => ({ ...delta })) });
  }

  flush(): ApplyQueueEntry[] {
    const pending = this.entries;
    this.entries = [];
    return pending;
  }

  drainAtBoundary(blackboard: Blackboard): QueueDrainResult {
    const pending = this.entries;
    this.entries = [];
    const applied: AppliedQueueEntry[] = [];
    const discarded: ApplyQueueEntry[] = [];

    pending.forEach((entry, index) => {
      const superseded = pending.slice(index + 1).some((newer) => covers(newer.turnRange, entry.turnRange));
      if (superseded) {
        discarded.push(entry);
        return;
      }
      const outcomes = entry.deltas.map((delta) => blackboard.applyDelta(delta));
      applied.push({ ...entry, outcomes });
    });

    return { applied, discarded };
  }

  get size(): number {
    return this.entries.length;
  }

  peek(): ApplyQueueEntry[] {
    return this.entries.map((entry) => ({ ...entry, deltas: entry.deltas.map((delta) => ({ ...delta })) }));
  }
}
