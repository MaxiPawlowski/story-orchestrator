param(
    [string]$Source = (Resolve-Path "$PSScriptRoot/../..").Path,
    [string]$HostSource = 'C:\dev\SillyTavern-MainBranch',
    [string]$Destination = "$env:TEMP\story-orchestrator-review-20260918"
)
$ErrorActionPreference = 'Stop'
$Source = [IO.Path]::GetFullPath($Source)
$HostSource = [IO.Path]::GetFullPath($HostSource)
$Destination = [IO.Path]::GetFullPath($Destination)
if ($Destination.StartsWith($HostSource, [StringComparison]::OrdinalIgnoreCase)) { throw 'Review copy must be outside the original host.' }
if (Test-Path -LiteralPath $Destination) { throw "Destination already exists: $Destination" }
$evidence = Join-Path $Source 'docs/review/2026-09-18/evidence'
New-Item -ItemType Directory -Force -Path $Destination,$evidence | Out-Null
$head = git -C $Source rev-parse HEAD
$status = git -C $Source status --porcelain=v1
$status | Set-Content -Encoding UTF8 (Join-Path $evidence 'baseline-status.txt')
git -C $Source log --all --format='%h %ad %s' --date=iso-strict | Set-Content -Encoding UTF8 (Join-Path $evidence 'history.txt')
$files = @(git -C $Source ls-files --cached --others --exclude-standard) | Sort-Object -Unique
$manifest = foreach ($relative in $files) {
    $path = Join-Path $Source $relative
    if (Test-Path -LiteralPath $path -PathType Leaf) {
        $item = Get-Item -LiteralPath $path
        [pscustomobject]@{ path=$relative; bytes=$item.Length; sha256=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower(); review='inventoried' }
    }
}
$manifest | ConvertTo-Json -Depth 4 | Set-Content -Encoding UTF8 (Join-Path $evidence 'inventory.json')
$copyHost = Join-Path $Destination 'host'
robocopy $HostSource $copyHost /E /XJ /XD .git node_modules data backups cache uploads plugins third-party .gemini .vscode /XF config.yaml config.conf.bak /R:1 /W:1 /NFL /NDL /NJH /NJS | Out-Null
if ($LASTEXITCODE -ge 8) { throw "Host copy failed: $LASTEXITCODE" }
$copyExtension = Join-Path $copyHost 'public/scripts/extensions/third-party/story-orchestrator'
New-Item -ItemType Directory -Force -Path $copyExtension | Out-Null
foreach ($entry in $manifest) {
    $target = Join-Path $copyExtension $entry.path
    New-Item -ItemType Directory -Force -Path (Split-Path $target) | Out-Null
    Copy-Item -LiteralPath (Join-Path $Source $entry.path) -Destination $target
}
$config = Get-Content -LiteralPath (Join-Path $HostSource 'default/config.yaml') -Raw
$config = $config -replace '(?m)^port: 8000\s*$', 'port: 18000'
$config = $config -replace '(?m)^(\s*)enabled: true', '$1enabled: false'
$config | Set-Content -Encoding UTF8 (Join-Path $copyHost 'config.yaml')
[pscustomobject]@{created=(Get-Date).ToUniversalTime().ToString('o'); source=$Source; revision=$head; hostSource=$HostSource; root=$Destination; host=$copyHost; extension=$copyExtension; port=18000; cdpPort=19222; copiedFiles=$manifest.Count} | ConvertTo-Json | Tee-Object -FilePath (Join-Path $evidence 'environment.json') | Set-Content -Encoding UTF8 (Join-Path $Destination 'environment.json')
Write-Output "Isolated review: $Destination ($($manifest.Count) extension files)"
